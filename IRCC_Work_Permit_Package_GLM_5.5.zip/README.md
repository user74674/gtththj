IRCC Work Permit Package — Round 3 revision (GLM 5.5)

Contents (23 files). All files were regenerated in the Round 3 pass of October 24, 2026, per the Officer-View Review, Round 3 findings and the applicant's decisions D1–D5.

Filed with the application, in reading order:
- Applicant_Cover_Letter_IRCC.docx — cover letter (rebuilt Sections 5–8)
- DOCUMENT 0 - Officer's Guide.docx — NEW: two-page guide filed after the cover letter
- DOCUMENT_1 Claude.docx — CFFB charitable status and mandate
- DOCUMENT 2 - Claude.docx — educational rationale (CG-030)
- DOCUMENT_3 Claude.docx — syllabus (compressed January 2028 schedule)
- DOCUMENT 4 Claude.docx — instructor qualifications (gap lines and course counts added)
- DOCUMENT_5_Claude.docx — selection, role, oversight, funding (documented search narrative)
- DOCUMENT 6 - Criteria Mapping and Evidence Index.docx — criteria mapping, exhibit cross-walk
- Job_Offer_Opus_2.docx — offer of employment (January 3 – February 4, 2028; hosted lodging; hours by place)
- Resume_2.docx — résumé

Exhibit specifications and templates:
- Exhibit 1-F, 2-C, 4-I - CFFB Programme Confirmation and Approval Letter.docx
- Exhibit 2-A - Expressions of Interest.docx
- Exhibit 3-F - Venue Confirmation.docx
- Exhibit 5-A - CFFB Selection Record.docx (now includes item 0, the Instructor Search Brief)
- Exhibit 5-E - CFFB Statement of Non-Remuneration and Non-Monetary Support.docx
- Exhibit 5-G - Instructor Search Log.docx — NEW
- Exhibit E-4 - Funds Access Evidence.docx
- Exhibit F-1 - Visual Timeline.docx (regenerated chart)
- Exhibit H-4 - Background and Conflict-of-Interest Declaration.docx
- Exhibits D-1, D-2, C-3 - Employer and Institution Letters (Specifications).docx

Internal working files (NOT submitted to IRCC):
- CFFB Verification-Call Briefing (Internal).docx
- CFFB Telephone Assistant - RetailAI Profile, Voice Guidelines and Q&A Bank.docx
- Change Log and Open Items.docx (Part 5 records this round; Part 2 lists every open [[INPUT-nn]] placeholder)

Decisions applied: D1 = B (compressed Tuesday/Thursday cohort, January 4–27, 2028); D2 = B (lawful pre-departure transfer, at least CAD 15,000); D3 = B (CFFB-arranged lodging as a non-monetary benefit); D4 = A (Ontario employment-law opinion before signing); D5 = A (IRCC number answered by a person; the AI line is overflow-only).

Key canonical values: permit January 3 – February 4, 2028; close-out February 3, 2028; registration opens November 15, 2027 (minimum eight by December 10, 2027); postponement trigger December 17, 2027; estimated cost about CAD 6,710; liquid funds about CAD 50,000 (about 7.5×); DOB August 9, 1995. Application numbers were left unchanged at the applicant's instruction and must be unified before filing.
